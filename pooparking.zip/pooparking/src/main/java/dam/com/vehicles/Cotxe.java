package dam.com.vehicles;

public class Cotxe extends Vehicles {

    public Cotxe (String matricula) {

        setMatricula(matricula);
        setMida(MidaVehicle.MITJA);
    
    }

}
