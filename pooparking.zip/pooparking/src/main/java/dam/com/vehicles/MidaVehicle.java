package dam.com.vehicles;

public enum MidaVehicle {
    PETIT,
    MITJA,
    GRAN
}
