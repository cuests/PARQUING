package dam.com.vehicles;

public class Camio extends Vehicles {

    public Camio (String matricula) {

        setMatricula(matricula);
        setMida(MidaVehicle.GRAN);
    
    }

}
