package dam.com.vehicles;

public class Motocicleta  extends Vehicles {

    public Motocicleta (String matricula) {

        setMatricula(matricula);
        setMida(MidaVehicle.PETIT);
    
    }

}
